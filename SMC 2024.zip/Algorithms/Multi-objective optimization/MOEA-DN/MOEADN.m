classdef MOEADN < ALGORITHM
% <multi/many> <real/binary/permutation>
% Multiobjective evolutionary algorithm based on decomposition
% type --- 1 --- The type of aggregation function

%------------------------------- Reference --------------------------------
% Q. Zhang and H. Li, MOEA/D: A multiobjective evolutionary algorithm based
% on decomposition, IEEE Transactions on Evolutionary Computation, 2007,
% 11(6): 712-731.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            type = Algorithm.ParameterSet(1);

            %% Generate the weight vectors
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            T = ceil(Problem.N/10);

            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);

            %% Generate random population
            Population = Problem.Initialization();
            Z = min(Population.objs,[],1);

            %% Optimization
            while Algorithm.NotTerminated(Population)
                % For each solution
                for i = 1 : Problem.N
                    % Choose the parents
                    P = B(i,randperm(size(B,2)));

                    % Generate an offspring
                    Offspring = OperatorGAhalf(Population(P(1:2)));
                    PopObj    = [Population.objs; Offspring.obj];

                    % Update range
                    Z       = min(Z,Offspring.obj);
                    FrontNo = NDSort(PopObj,Problem.N+1);
                    Zmax   = max(PopObj(FrontNo==1,:),[],1);
                    a      = Zmax - Z + 1e-6;
                    % Normalization
                    PopObj_translated = PopObj - Z;
                    PopObj_normalized = PopObj_translated./a;

                    % Update the neighbours
                    switch type
                        case 1
                            % PBI approach
                            normW   = sqrt(sum(W(P,:).^2,2));
                            normP   = sqrt(sum(PopObj_normalized(P,:).^2,2));
                            normO   = sqrt(sum(PopObj_normalized(end,:).^2,2));
                            CosineP = sum(PopObj_normalized(P,:).*W(P,:),2)./normW./normP;
                            CosineO = sum(repmat(PopObj_normalized(end,:),T,1).*W(P,:),2)./normW./normO;
                            g_old   = normP.*CosineP + 5*normP.*sqrt(1-CosineP.^2);
                            g_new   = normO.*CosineO + 5*normO.*sqrt(1-CosineO.^2);
                        case 2
                            % Tchebycheff approach
                            g_old = max(abs(PopObj_normalized(P,:)).*W(P,:),[],2);
                            g_new = max(repmat(abs(PopObj_normalized(end,:)),T,1).*W(P,:),[],2);
                        case 3
                            % Modified Tchebycheff approach
                            g_old = max(abs(PopObj_normalized(P,:))./W(P,:),[],2);
                            g_new = max(repmat(abs(PopObj_normalized(end,:)),T,1)./W(P,:),[],2);
                        case 4
                            % Weighted sum 
                            g_old = sum((PopObj_normalized(P,:)).*(W(P,:)),2);
                            g_new = sum(repmat(PopObj_normalized(end,:), T, 1).*(W(P,:)),2);
                        case 5
                            % Angle Penalized Distance (APD)
                            % Calculate the smallest angle value between each vector and others
                            alpha  = 2;
                            theta  = (ceil(Problem.FE/Problem.N)/ceil(Problem.maxFE/Problem.N))^alpha;
                            cosine = 1 - pdist2(W,W,'cosine');
                            cosine(logical(eye(length(cosine)))) = 0;
                            gamma  = min(acos(cosine),[],2);
                            % Associate each solution to a reference vector
                            Angle = acos(1-pdist2(PopObj_normalized,W,'cosine'));
                            Angle_diag = diag(Angle);
                            g_old = (1+Problem.M*theta*Angle_diag(P)./gamma(P)).*sqrt(sum(PopObj_normalized(P,:).^2,2));
                            g_new = (1+Problem.M*theta*Angle(end,P)'./gamma(P)).*sqrt(sum(PopObj_normalized(end,:).^2,2));
                        case 6
                            % 2-Tch
                            % On Tchebycheff Decomposition Approaches for Multiobjective Evolutionary Optimization
                            p = 2;
                            normW = vecnorm(W,p,2);
                            g_old = normW(P).*max(abs(PopObj_normalized(P,:))./W(P,:),[],2);
                            g_new = normW(P).*max(repmat(abs(PopObj_normalized(end,:)),T,1)./W(P,:),[],2);
                        case 7
                            % Multiplicative Scalarizing Function (MSF)
                            % Scalarizing Functions in Decomposition-Based Multiobjective Evolutionary Algorithms
                            % when alpha = 0, gmsf = gmtch
                            beta  = 1;
                            gen_pct  = 1-ceil(Problem.FE/Problem.N)/ceil(Problem.maxFE/Problem.N);
                            alpha = beta * gen_pct * Problem.M * min(W,[],2);
                            gmtch_old = max(abs(PopObj_normalized(P,:))./W(P,:),[],2);
                            gmin_old  = min(abs(PopObj_normalized(P,:))./W(P,:),[],2);

                            gmtch_new = max(repmat(abs(PopObj_normalized(end,:)),T,1)./W(P,:),[],2);
                            gmin_new  = min(repmat(abs(PopObj_normalized(end,:)),T,1)./W(P,:),[],2);
                            
                            g_old = (gmtch_old).^(1+alpha(P))./(gmin_old).^alpha(P);
                            g_new = (gmtch_new).^(1+alpha(P))./(gmin_new).^alpha(P);
                        case 8
                            % Penalty-Based Scalarizing Function (PSF)
                            % Scalarizing Functions in Decomposition-Based Multiobjective Evolutionary Algorithms
                            % when alpha = 0, gpsf = gmtch
                            beta  = 10;
                            gen_pct  = 1-ceil(Problem.FE/Problem.N)/ceil(Problem.maxFE/Problem.N);
                            alpha = beta * gen_pct * Problem.M * min(W,[],2);
                            normW   = sqrt(sum(W(P,:).^2,2));
                            normP   = sqrt(sum(PopObj_normalized(P,:).^2,2));
                            normO   = sqrt(sum(PopObj_normalized(end,:).^2,2));
                            CosineP = sum(PopObj_normalized(P,:).*W(P,:),2)./normW./normP;
                            CosineO = sum(repmat(PopObj_normalized(end,:),T,1).*W(P,:),2)./normW./normO;
                            d2_old   = normP.*sqrt(1-CosineP.^2);
                            d2_new   = normO.*sqrt(1-CosineO.^2);
                            
                            g_old = max(abs(PopObj_normalized(P,:))./W(P,:),[],2) + alpha(P) .* d2_old;
                            g_new = max(repmat(abs(PopObj_normalized(end,:)),T,1)./W(P,:),[],2) + alpha(P) .* d2_new;
                    end
                    Population(P(g_old>=g_new)) = Offspring;
                end
            end
        end
    end
end