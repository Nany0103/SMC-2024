classdef NSGAIICNoNe < ALGORITHM
% <multi> <real/binary/permutation> <constrained/none>
% Nondominated sorting genetic algorithm II

%------------------------------- Reference --------------------------------
% K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, A fast and elitist
% multiobjective genetic algorithm: NSGA-II, IEEE Transactions on
% Evolutionary Computation, 2002, 6(2): 182-197.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population = Problem.Initialization();
            [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,Problem.N);
            constraints = Problem.CalCon(Population.decs);
            cmin = min(constraints);
            cmax = max(constraints);
            % normalize constraints
            normCons = NormConstraint(constraints,cmin,cmax);
            % modify the last objective based on the normalized constraints
            for i = 1:length(Population)
                Population(i).update_NoNe(normCons(i,:));
            end

            %% Optimization
            while Algorithm.NotTerminated(Population)
                MatingPool = TournamentSelection(2,Problem.N,FrontNo,-CrowdDis);
                Offspring  = OperatorGA(Population(MatingPool));
                % update cmin and cmax
                consOff = Problem.CalCon(Offspring.decs);
                consPop = Problem.CalCon(Population.decs);
                cmin = min([cmin;consOff]);
                cmax = max([cmax;consOff]);
                % normalize offspring constaints and population constraints
                normConsOff = NormConstraint(consOff,cmin,cmax);
                normConsPop = NormConstraint(consPop,cmin,cmax);
                % modify the last objective for population and offspring
                for i = 1:length(Population)
                    Population(i).update_NoNe(normConsPop(i,:));
                end
                for i = 1:length(Offspring)
                    Offspring(i).update_NoNe(normConsOff(i,:));
                end
                [Population,FrontNo,CrowdDis] = EnvironmentalSelection([Population,Offspring],Problem.N);
            end
        end
    end
end